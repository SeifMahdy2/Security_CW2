from flask import Blueprint, render_template, redirect, request, session, flash
from flask_wtf.csrf import generate_csrf
import libuser
import libsession

mod_user = Blueprint('mod_user', __name__, template_folder='templates')

@mod_user.route('/login', methods=['GET', 'POST'])
def do_login():
    session.pop('username', None)  # Clear any existing session

    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        # Input validation
        if not username or not password:
            flash("Username and password cannot be empty")
            return render_template('user.login.mfa.html', csrf_token=generate_csrf())

        # Authenticate user
        username = libuser.login(username, password)
        if not username:
            flash("Invalid user or password")
            return render_template('user.login.mfa.html', csrf_token=generate_csrf())

        # Create secure session
        response = redirect('/')
        response = libsession.create(response, username)
        return response

    return render_template('user.login.mfa.html', csrf_token=generate_csrf())
