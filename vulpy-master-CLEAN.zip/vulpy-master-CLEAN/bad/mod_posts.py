import sqlite3
import html
from flask_wtf.csrf import generate_csrf  # Import CSRF generator

from flask import Blueprint, render_template, redirect, request, g

import libposts
import libuser

mod_posts = Blueprint('mod_posts', __name__, template_folder='templates')


@mod_posts.route('/')
@mod_posts.route('/<username>')
def do_view(username=None):

    if not username:
        if 'username' in g.session:
            username = g.session['username']

    posts = libposts.get_posts(username)
    users = libuser.userlist()

    # Pass CSRF token to the template
    return render_template('posts.view.html', posts=posts, username=username, users=users, csrf_token=generate_csrf())


@mod_posts.route('/', methods=['POST'])
def do_create():

    if 'username' not in g.session:
        return redirect('/user/login')

    if request.method == 'POST':
        username = g.session['username']
        text = request.form.get('text')

        # Sanitiztion of the input preventing XSS from happening
        safe_text = html.escape(text)

        libposts.post(username, safe_text)

    return redirect('/')