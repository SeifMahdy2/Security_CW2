from pathlib import Path
from flask import Flask, g, redirect, request, session, url_for
from flask_wtf.csrf import CSRFProtect
from flask_sslify import SSLify
import libsession
from mod_api import mod_api
from mod_csp import mod_csp
from mod_hello import mod_hello
from mod_mfa import mod_mfa
from mod_posts import mod_posts
from mod_user import mod_user
from datetime import timedelta

app = Flask('vulpy')
app.config['SECRET_KEY'] = 'aaaaaaa'
csrf = CSRFProtect(app)  # Enable CSRF protection

sslify = SSLify(app)

# Secure session settings
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_SECURE'] = True
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(minutes=30)

# Register blueprints
app.register_blueprint(mod_hello, url_prefix='/hello')
app.register_blueprint(mod_user, url_prefix='/user')
app.register_blueprint(mod_posts, url_prefix='/posts')
app.register_blueprint(mod_mfa, url_prefix='/mfa')
app.register_blueprint(mod_csp, url_prefix='/csp')
app.register_blueprint(mod_api, url_prefix='/api')

# Content Security Policy (CSP) setup
csp_file = Path('csp.txt')
csp = ''
if csp_file.is_file():
    with csp_file.open() as f:
        for line in f.readlines():
            if line.startswith('#'):
                continue
            line = line.replace('\n', '')
            if line:
                csp += line
if csp:
    print('CSP:', csp)

@app.before_request
def before_request():
    """
    Load session and restrict access to authenticated routes.
    """
    g.session = libsession.load(request)  # Load session data

    # Restricted routes that require login
    restricted_routes = ['/posts', '/mfa', '/csp', '/api']

    if any(request.path.startswith(route) for route in restricted_routes):
        if 'username' not in session:  # Check if session is valid
            return redirect(url_for('mod_user.do_login'))  # Redirect to login page

@app.route('/')
def do_home():
    """
    Home page: Redirect to posts if authenticated, else login.
    """
    if 'username' in session:
        return redirect('/posts')
    return redirect('/user/login')

@app.after_request
def add_csp_headers(response):
    """
    Add Content-Security-Policy headers after every request.
    """
    if csp:
        response.headers['Content-Security-Policy'] = csp
    return response
@app.after_request
def add_security_headers(response):
    response.headers['X-Frame-Options'] = 'DENY'  # Prevents the page from being embedded
    response.headers['Content-Security-Policy'] = "frame-ancestors 'none';"  # CSP for Clickjacking
    return response

def add_secure_headers(response):
    response.headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains'
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-XSS-Protection'] = '1; mode=block'
    return response


# Run the Flask app
if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000, extra_files='csp.txt')