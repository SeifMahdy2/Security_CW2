import sqlite3
from werkzeug.security import check_password_hash

from werkzeug.security import check_password_hash
import sqlite3

def login(username, password):
    """
    Authenticate user securely by verifying username and password.
    """
    if not username or not password:  # Ensure input is not empty
        return False

    conn = sqlite3.connect('db_users.sqlite')
    conn.row_factory = sqlite3.Row
    c = conn.cursor()

    # Fetch user by username
    user = c.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()
    conn.close()

    # Check if user exists and verify hashed password
    if user and user['password'] == password:
        return user['username']  # Return username if successful
    else:
        return False


def create(username, password):
    conn = sqlite3.connect('db_users.sqlite')
    c = conn.cursor()

    c.execute("INSERT INTO users (username, password, failures, mfa_enabled, mfa_secret) VALUES ('%s', '%s', '%d', '%d', '%s')" % (username, password, 0, 0, ''))

    conn.commit()
    conn.close()

def password_change(username, password):
    conn = sqlite3.connect('db_users.sqlite')
    conn.row_factory = sqlite3.Row
    c = conn.cursor()

    c.execute("UPDATE users SET password = '{}' WHERE username = '{}'".format(password, username))
    conn.commit()
    return True

def get_failures(username):
    conn = sqlite3.connect('users.sqlite')
    c = conn.cursor()
    c.execute("SELECT failures FROM users WHERE user = ?", (username,))
    result = c.fetchone()
    conn.close()
    return result[0] if result else 0

def increment_failures(username):
    conn = sqlite3.connect('users.sqlite')
    c = conn.cursor()
    c.execute("UPDATE users SET failures = failures + 1 WHERE user = ?", (username,))
    conn.commit()
    conn.close()

def reset_failures(username):
    conn = sqlite3.connect('users.sqlite')
    c = conn.cursor()
    c.execute("UPDATE users SET failures = 0 WHERE user = ?", (username,))
    conn.commit()
    conn.close()

def password_complexity(password):
    return True

def userlist():
    """
    Retrieve a list of all usernames from the database.
    """
    conn = sqlite3.connect('db_users.sqlite')
    conn.set_trace_callback(print)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()

    users = c.execute("SELECT * FROM users").fetchall()

    if not users:
        return []
    else:
        return [user['username'] for user in users]
