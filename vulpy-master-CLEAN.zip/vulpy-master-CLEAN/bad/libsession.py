from flask import session, request, make_response

def create(response, username):
    """
    Create a new session and store the username securely.
    """
    session['username'] = username  # Securely store username in session
    response = make_response(response)
    return response

def load(request=None):
    """
    Load session data securely. Accepts 'request' for cookie validation (optional).
    """
    # If needed, you can read cookies here; for now, just use session directly
    return {'username': session.get('username')}  # Load session data

def destroy(response):
    """
    Destroy the current session by clearing session data and expiring the cookie.
    """
    session.clear()  # Clear all session data
    response.set_cookie('vulpy_session', '', expires=0, httponly=True, secure=True, samesite='Lax')
    return response
